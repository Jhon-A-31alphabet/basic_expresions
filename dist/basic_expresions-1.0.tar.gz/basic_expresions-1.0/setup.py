from setuptools import setup,find_packages

setup(
    name="basic_expresions",
    version = "1.0",
    author = "Jhon Marcos Araujo",
    
    description = "this is my own library it was made to make easier work with regular expresions.",
    packages=find_packages()

)